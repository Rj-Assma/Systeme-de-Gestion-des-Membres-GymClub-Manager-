from django import forms
from .models import Membre, TypeAbonnement, Paiement

class MembreForm(forms.ModelForm):
    class Meta:
        model = Membre
        fields = ['nom', 'email', 'telephone', 'type_abonnement', 'duree', 'date_inscription']
        widgets = {
            'nom': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nom complet'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'email@exemple.com'}),
            'telephone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Téléphone'}),
            'type_abonnement': forms.Select(attrs={'class': 'form-select'}),
            'duree': forms.Select(attrs={'class': 'form-select'}),
            'date_inscription': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        }

class PaiementForm(forms.ModelForm):
    class Meta:
        model = Paiement
        fields = ['montant']
        widgets = {
            'montant': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Montant en DH'}),
        }