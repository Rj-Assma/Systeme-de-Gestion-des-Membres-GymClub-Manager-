from django.contrib import admin
from .models import Membre, TypeAbonnement, Paiement

# 1. Définir l'Inline en premier
class PaiementInline(admin.TabularInline):
    model = Paiement
    extra = 1 # Permet d'ajouter une ligne de paiement vide sur la fiche membre
    fields = ['montant', 'methode'] 

# 2. Configurer Membre avec inline
@admin.register(Membre)
class MembreAdmin(admin.ModelAdmin):
    list_display = ['nom', 'email', 'type_abonnement', 'date_inscription', 'date_expiration', 'est_actif']
    list_filter = ['type_abonnement', 'date_inscription']
    search_fields = ['nom', 'email']
    date_hierarchy = 'date_inscription'
    inlines = [PaiementInline] 

# 3. Configurer TypeAbonnement
@admin.register(TypeAbonnement)
class TypeAbonnementAdmin(admin.ModelAdmin):
    list_display = ['libelle', 'prix_mensuel']

# 4. Configurer Paiement (vue séparée)
@admin.register(Paiement)
class PaiementAdmin(admin.ModelAdmin):
    list_display = ['membre', 'montant', 'methode', 'date_paiement']
    list_filter = ['date_paiement', 'methode']
    search_fields = ['membre__nom']
    
