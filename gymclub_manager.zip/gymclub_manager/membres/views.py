from django.shortcuts import render

# Create your views here.
from django.shortcuts import redirect, get_object_or_404
from django.db.models import Q
from django.utils import timezone
from .models import Membre, TypeAbonnement, Paiement
from .forms import MembreForm
from django.contrib import messages

def dashboard(request):
    total_membres = Membre.objects.count()
    membres_actifs = sum(1 for m in Membre.objects.all() if m.est_actif)
    membres_expires = total_membres - membres_actifs
    
    context = {
        'total_membres': total_membres,
        'membres_actifs': membres_actifs,
        'membres_expires': membres_expires,
    }
    return render(request, 'membres/dashboard.html', context)

def liste_membres(request):
    membres = Membre.objects.all().order_by('-date_inscription')
    statut_filtre = request.GET.get('statut', '')  # Récupère le paramètre de statut (actif/expire)

    if statut_filtre == 'actif':
        # garde que ceux dont la date d'expiration est dans le futur ou aujourd'hui
        membres = [m for m in membres if m.est_actif]
    elif statut_filtre == 'expire':
        # garde que ceux qui sont expirés 
        membres = [m for m in membres if not m.est_actif]
        
    return render(request, 'membres/liste_membres.html', {'membres': membres})

def ajouter_membre(request):
    if request.method == 'POST':
        form = MembreForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('liste_membres')
    else:
        form = MembreForm()
    return render(request, 'membres/ajouter_membre.html', {'form': form})

def detail_membre(request, pk):
    membre = get_object_or_404(Membre, pk=pk)
    return render(request, 'membres/detail_membre.html', {'membre': membre})

def modifier_membre(request, pk):
    membre = get_object_or_404(Membre, pk=pk)
    if request.method == 'POST':
        form = MembreForm(request.POST, instance=membre)
        if form.is_valid():
            form.save()
            return redirect('detail_membre', pk=pk)
    else:
        form = MembreForm(instance=membre)
    return render(request, 'membres/ajouter_membre.html', {'form': form, 'membre': membre})

# def supprimer_membre(request, pk):
#     membre = get_object_or_404(Membre, pk=pk)
#     if request.method == 'POST':
#         membre.delete()
#         return redirect('liste_membres')
#     return render(request, 'membres/supprimer_membre.html', {'membre': membre})

def delete_member(request, pk):
    membre = get_object_or_404(Membre, pk=pk)
    membre.delete()
    # Ce message apparaîtra sur le dashboard
    messages.success(request, f"Le membre {membre.nom} a été supprimé.")
    return redirect('liste_membres')

def recherche_membre(request):
    query = request.GET.get('q', '')
    type_filter = request.GET.get('type', '')
    statut = request.GET.get('statut', '')
    
    membres = Membre.objects.all()
    
    if query:
        membres = membres.filter(
            Q(nom__icontains=query) | Q(email__icontains=query)
        )
    
    if type_filter:
        membres = membres.filter(type_abonnement__libelle=type_filter)
    
    if statut == 'actif':
        membres = [m for m in membres if m.est_actif]
    elif statut == 'expire':
        membres = [m for m in membres if not m.est_actif]
    
    types = TypeAbonnement.objects.all()
    
    return render(request, 'membres/liste_membres.html', {
        'membres': membres,
        'query': query,
        'types': types,
        'type_filter': type_filter,
        'statut': statut,
    })
    
def liste_paiements(request):
    # Récupère tous les paiements du plus récent au plus ancien-all order by date_paiement desc
    paiements = Paiement.objects.all().order_by('-date_paiement')
    return render(request, 'paiements/liste_paiements.html', {'paiements': paiements})
def ajouter_paiement(request, pk):
    membre = get_object_or_404(Membre, pk=pk)
    
    if request.method == "POST":
        montant = request.POST.get('montant')
        methode = request.POST.get('methode')
        
        Paiement.objects.create(
            membre=membre,
            montant=montant,
            methode=methode
        )
        messages.success(request, f"Paiement de {montant} DH validé pour {membre.nom}.")
        return redirect('liste_membres')

    return render(request, 'paiements/ajouter_paiement.html', {'membre': membre})