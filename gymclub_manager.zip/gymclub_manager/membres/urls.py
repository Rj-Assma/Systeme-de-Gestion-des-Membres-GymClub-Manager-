from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('membres/', views.liste_membres, name='liste_membres'),
    path('membres/ajouter/', views.ajouter_membre, name='ajouter_membre'),
    path('membres/<int:pk>/', views.detail_membre, name='detail_membre'),
    path('membres/modifier/<int:pk>/', views.modifier_membre, name='modifier_membre'),
    # path('membres/supprimer/<int:pk>/', views.supprimer_membre, name='supprimer_membre'),
    path('membres/supprimer/<int:pk>/', views.delete_member, name='delete_member'),
    path('membres/recherche/', views.recherche_membre, name='recherche_membre'),
    path('paiements/', views.liste_paiements, name='liste_paiements'),
    path('paiements/ajouter/<int:pk>/', views.ajouter_paiement, name='ajouter_paiement'),
]