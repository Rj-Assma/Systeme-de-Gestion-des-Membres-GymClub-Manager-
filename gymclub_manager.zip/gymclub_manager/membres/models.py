from django.db import models

# Create your models here.
from django.utils import timezone
from datetime import timedelta

class TypeAbonnement(models.Model):
    LIBELLES = [
        ('standard', 'Standard'),
        ('premium', 'Premium'),
        ('etudiant', 'Étudiant'),
        ('entreprise', 'Entreprise'),
    ]
    
    libelle = models.CharField(max_length=20, choices=LIBELLES, unique=True)
    prix_mensuel = models.DecimalField(max_digits=8, decimal_places=2)
    avantages = models.TextField(blank=True)
    
    def __str__(self):
        return self.libelle.capitalize()

class Membre(models.Model):
    DUREES = [
        (1, 'Mensuel'),
        (3, 'Trimestriel'),
        (6, 'Semestriel'),
        (12, 'Annuel'),
    ]
    
    nom = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    telephone = models.CharField(max_length=20, blank=True)
    type_abonnement = models.ForeignKey(TypeAbonnement, on_delete=models.PROTECT)
    duree = models.IntegerField(choices=DUREES, default=1)
    date_inscription = models.DateField(default=timezone.now)
    
    
    def date_expiration(self):
        return self.date_inscription + timedelta(days=30 * self.duree)
    
    @property
    def est_actif(self):
        return self.date_expiration() >= timezone.now().date()
    
    def __str__(self):
        return f"{self.nom} ({self.type_abonnement})"
    

# models.py
class Paiement(models.Model):
    # Le related_name='paiements' est TRÈS important pour l'Inline
    membre = models.ForeignKey(Membre, on_delete=models.CASCADE, related_name='paiements')
    montant = models.DecimalField(max_digits=10, decimal_places=2)
    methode = models.CharField(max_length=50)
    date_paiement = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.membre.nom} - {self.montant} DH"